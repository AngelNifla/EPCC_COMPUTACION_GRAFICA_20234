#include <GL/glut.h>
#include <vector>
#include <cmath>
#include <random>
#include <iostream>

// Defiendo M_PI como pi
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

std::vector<float> porcentajes(10); // { 10.0, 7.0, 13.0, 5.0, 13.0, 14.0, 3.0, 16.0, 5.0, 3.0, 17.0, 8.0 };
std::vector<std::vector<float>> colores = {
    {1.0, 0.0, 0.0}, // Rojo
    {0.0, 1.0, 0.0}, // Verde
    {0.0, 0.0, 1.0}, // Azul
    {1.0, 1.0, 0.0}, // Amarillo
    {0.0, 1.0, 1.0}, // Cian
    {1.0, 0.0, 1.0}, // Magenta
    {0.5, 0.5, 0.5}, // Gris
    {0.5, 0.0, 0.5}, // P�rpura
    {0.5, 0.5, 0.0}, // Oliva
    {0.0, 0.5, 0.5}, // Teal
    {1.0, 0.5, 0.0}, // Naranja
    {0.5, 0.0, 0.0}  // Marr�n
};

void Mostrar_Pantalla()
{
    glClear(GL_COLOR_BUFFER_BIT);

    float total = 0;
    for (float p : porcentajes)
    {
        total += p;
    }

    float Angulo_inicial = 0.0f;

    for (int i = 0; i < porcentajes.size(); ++i)
    {
        float p = porcentajes[i];
        float Angulo_final = Angulo_inicial + (p / total) * 360.0f;
        std::vector<float> color = colores[i % colores.size()];

        glColor3f(color[0], color[1], color[2]);

        glBegin(GL_TRIANGLE_FAN);
        glVertex2f(0.0f, 0.0f); // Centro del c�rculo

        for (float angulo = Angulo_inicial; angulo <= Angulo_final; angulo += 0.1f)
        {
            float radian = angulo * M_PI / 180.0f;
            glVertex2f(cos(radian), sin(radian));
        }
        glEnd();

        Angulo_inicial = Angulo_final;
    }

    glFlush();
}

void init()
{
    glClearColor(1.0, 1.0, 1.0, 1.0); // Fondo blanco
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0); // Coordenadas
}

int main(int argc, char** argv)
{

    // N�meros aleatorios
    std::random_device rd;  // Semilla aleatoria
    std::mt19937 gen(rd()); // Inicializando el generador de n�meros aleatorios
    std::uniform_real_distribution<> dis(0.0, 20.0); // Rango [0.0, 20.0]

    // Generando los 10 n�meros aleatorios
    for (float& num : porcentajes)
    {
        num = dis(gen);
    }

    // Mostrando los n�meros aleatorios
    std::cout << "Numeros aleatorios:\n";
    for (const float& num : porcentajes)
    {
        std::cout << num << std::endl;
    }
    ////////////////////////////////////////////////////////
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Grafico de Sectores Circular");

    init();

    glutDisplayFunc(Mostrar_Pantalla);
    glutMainLoop();
    return 0;
}
