
/*#include <GL/glut.h>  // Incluir la biblioteca GLUT

// Funci�n para dibujar en la pantalla
void display() {
    glClear(GL_COLOR_BUFFER_BIT);  // Limpiar el buffer de color

    // Dibuja un tri�ngulo
    glBegin(GL_TRIANGLES);
    glColor3f(1.0, 0.0, 0.0);  // Color rojo
    glVertex2f(-0.5, -0.5);
    glColor3f(0.0, 1.0, 0.0);  // Color verde
    glVertex2f(0.5, -0.5);
    glColor3f(0.0, 0.0, 1.0);  // Color azul
    glVertex2f(0.0, 0.5);
    glEnd();

    glFlush();  // Forzar a OpenGL a renderizar ahora
}

// Funci�n principal
int main(int argc, char** argv) {
    glutInit(&argc, argv);  // Inicializar GLUT
    glutCreateWindow("Ejemplo de OpenGL con GLUT");  // Crear una ventana con t�tulo
    glutDisplayFunc(display);  // Especificar la funci�n de dibujo
    glutMainLoop();  // Entrar al ciclo principal de GLUT

    return 0;
}*/

#include <GL/glut.h>
#include <iostream>
#include <cmath>

struct Casa {
    int x; // Origen en x
    int y; // Origen en y
    int altura; // Altura de la casa
    int ancho; // Ancho de la casa
};

struct Carro {
    int x; // Origen en x
    int y; // Origen en y
    int altura; // Altura del carro
    int ancho; // Ancho del carro
};

void init() {
    glClearColor(1.0, 1.0, 1.0, 1.0); // Fondo blanco
    glColor3f(0.0, 0.0, 0.0); // Color de la l�nea: negro
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(0, 800, 0, 600); // Definir el �rea de dibujo
}

void setPixel(int x, int y) {
    glBegin(GL_POINTS);
    glVertex2i(x, y);
    glEnd();
}

void DDA(int x1, int y1, int x2, int y2) {
    int dx = x2 - x1;
    int dy = y2 - y1;
    int steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy);
    float xIncrement = dx / (float)steps;
    float yIncrement = dy / (float)steps;

    float x = x1;
    float y = y1;
    for (int i = 0; i <= steps; i++) {
        setPixel(round(x), round(y));
        x += xIncrement;
        y += yIncrement;
    }
}

void Bresenham(int x1, int y1, int x2, int y2) {
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);
    int p = 2 * dy - dx;
    int twody = 2 * dy;
    int twodydx = 2 * (dy - dx);
    int x, y, xEnd;

    if (x1 > x2) {
        x = x2;
        y = y2;
        xEnd = x1;
    }
    else {
        x = x1;
        y = y1;
        xEnd = x2;
    }

    setPixel(x, y);

    while (x < xEnd) {
        x++;
        if (p < 0) {
            p += twody;
        }
        else {
            y++;
            p += twodydx;
        }
        setPixel(x, y);
    }
}

void DottedLine(int x1, int y1, int x2, int y2) {
    glColor3f(1.0, 0.0, 0.0); // Color rojo para l�nea punteada
    glEnable(GL_LINE_STIPPLE);
    glLineStipple(1, 0x00FF); // Patr�n para l�nea punteada

    glBegin(GL_LINES);
    glVertex2i(x1, y1);
    glVertex2i(x2, y2);
    glEnd();

    glDisable(GL_LINE_STIPPLE);
}

void DashedLine(int x1, int y1, int x2, int y2) {
    glColor3f(0.0, 0.0, 1.0); // Color azul para l�nea discontinua
    glEnable(GL_LINE_STIPPLE);
    glLineStipple(1, 0x0F0F); // Patr�n para l�nea discontinua

    glBegin(GL_LINES);
    glVertex2i(x1, y1);
    glVertex2i(x2, y2);
    glEnd();

    glDisable(GL_LINE_STIPPLE);
}

void SolidLine(int x1, int y1, int x2, int y2) {
    glColor3f(0.0, 0.0, 0.0); // Color negro para l�nea s�lida

    glBegin(GL_LINES);
    glVertex2i(x1, y1);
    glVertex2i(x2, y2);
    glEnd();
}

void crearCasa(Casa& C) {
    // Fachada de la casa (rect�ngulo)
    glColor3f(1.0, 0.0, 0.0); // Rojo
    glBegin(GL_QUADS);
    glVertex2i(C.x, C.y);
    glVertex2i(C.x + C.ancho, C.y);
    glVertex2i(C.x + C.ancho, C.y + C.altura);
    glVertex2i(C.x, C.y + C.altura);
    glEnd();

    // Techo de la casa (tri�ngulo)
    glColor3f(0.0, 0.0, 1.0); // Azul
    glBegin(GL_TRIANGLES);
    glVertex2i(C.x, C.y + C.altura);
    glVertex2i(C.x + C.ancho / 2, C.y + C.altura * 2);
    glVertex2i(C.x + C.ancho, C.y + C.altura);
    glEnd();

    // Puerta de la casa (rect�ngulo)
    glColor3f(0.0, 1.0, 0.0); // Verde
    glBegin(GL_QUADS);
    glVertex2i(C.x + C.ancho / 4, C.y);
    glVertex2i(C.x + 3 * C.ancho / 4, C.y);
    glVertex2i(C.x + 3 * C.ancho / 4, C.y + C.altura / 2);
    glVertex2i(C.x + C.ancho / 4, C.y + C.altura / 2);
    glEnd();

    // Ventanas de la casa (cuadrados)
    glColor3f(1.0, 1.0, 0.0); // Amarillo
    glBegin(GL_QUADS);
    glVertex2i(C.x + C.ancho / 6, C.y + C.altura / 2);
    glVertex2i(C.x + C.ancho / 3, C.y + C.altura / 2);
    glVertex2i(C.x + C.ancho / 3, C.y + 2 * C.altura / 3);
    glVertex2i(C.x + C.ancho / 6, C.y + 2 * C.altura / 3);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2i(C.x + 2 * C.ancho / 3, C.y + C.altura / 2);
    glVertex2i(C.x + 5 * C.ancho / 6, C.y + C.altura / 2);
    glVertex2i(C.x + 5 * C.ancho / 6, C.y + 2 * C.altura / 3);
    glVertex2i(C.x + 2 * C.ancho / 3, C.y + 2 * C.altura / 3);
    glEnd();
}

void dibujarCasa() {
    Casa C;
    C.x = 100;
    C.y = 100;
    C.altura = 150;
    C.ancho = 200;
    crearCasa(C);
}

void crearCarro(Carro& V) {
    // Cuerpo del carro (rect�ngulo)
    glColor3f(0.0, 1.0, 1.0); // Cian
    glBegin(GL_QUADS);
    glVertex2i(V.x, V.y);
    glVertex2i(V.x + V.ancho, V.y);
    glVertex2i(V.x + V.ancho, V.y + V.altura / 2);
    glVertex2i(V.x, V.y + V.altura / 2);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2i(V.x+10, V.y+1);
    glVertex2i(V.x-10 + V.ancho, V.y+1);
    glVertex2i(V.x-12 + V.ancho, V.y + 2*V.altura / 2);
    glVertex2i(V.x+12, V.y + 2*V.altura / 2);
    glEnd();


    // Ventanas del carro (cuadrados)
    glColor3f(1.0, 0.0, 1.0); // Magenta
    glBegin(GL_QUADS);
    glVertex2i(V.x + V.ancho / 6, V.y + V.altura / 4);
    glVertex2i(V.x + 2 * V.ancho / 6, V.y + V.altura / 4);
    glVertex2i(V.x + 2 * V.ancho / 6, V.y + 3 * V.altura / 4);
    glVertex2i(V.x + V.ancho / 6, V.y + 3 * V.altura / 4);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2i(V.x + 4 * V.ancho / 6, V.y + V.altura / 4);
    glVertex2i(V.x + 5 * V.ancho / 6, V.y + V.altura / 4);
    glVertex2i(V.x + 5 * V.ancho / 6, V.y + 3 * V.altura / 4);
    glVertex2i(V.x + 4 * V.ancho / 6, V.y + 3 * V.altura / 4);
    glEnd();

    // Llantas del carro (c�rculos)
    glColor3f(0.0, 0.0, 0.0); // Negro
    glBegin(GL_POLYGON);
    for (int i = 0; i < 360; i++) {
        float theta = i * 3.14159 / 180;
        glVertex2f(V.x + V.ancho / 5 + cos(theta) * V.ancho / 10, V.y + V.altura / 4 + sin(theta) * V.altura / 4);
    }
    glEnd();

    glBegin(GL_POLYGON);
    for (int i = 0; i < 360; i++) {
        float theta = i * 3.14159 / 180;
        glVertex2f(V.x + 4 * V.ancho / 5 + cos(theta) * V.ancho / 10, V.y + V.altura / 4 + sin(theta) * V.altura / 4);
    }
    glEnd();
}

void dibujarCarro() {
    Carro V;
    V.x = 400;
    V.y = 100;
    V.altura = 50;
    V.ancho = 100;
    crearCarro(V);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Dibujar casa y carro
    dibujarCasa();
    dibujarCarro();

    // Dibujar l�neas con diferentes estilos
    glLineWidth(2.0); // Ancho de l�nea

    // L�nea s�lida
    SolidLine(50, 50, 200, 50);

    // L�nea punteada
    DottedLine(50, 100, 200, 100);

    // L�nea discontinua
    DashedLine(50, 150, 200, 150);

    // L�nea con algoritmo DDA
    DDA(50, 200, 200, 200);

    // L�nea con algoritmo Bresenham
    Bresenham(50, 250, 200, 250);

    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Casa y Carro");
    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}

/*
#include <GL/glut.h>
#include <iostream>
#include <cmath>

struct Casa {
    int x; // Origen en x
    int y; // Origen en y
    int altura; // Altura de la casa
    int ancho; // Ancho de la casa
};

struct Carro {
    int x; // Origen en x
    int y; // Origen en y
    int altura; // Altura del carro
    int ancho; // Ancho del carro
};

void init() {
    glClearColor(1.0, 1.0, 1.0, 1.0); // Fondo blanco
    glColor3f(0.0, 0.0, 0.0); // Color de la l�nea: negro
    glMatrixMode(GL_PROJECTION);
    gluOrtho2D(0, 800, 0, 600); // Definir el �rea de dibujo
}

void setPixel(int x, int y) {
    glBegin(GL_POINTS);
    glVertex2i(x, y);
    glEnd();
}

void DDA(int x1, int y1, int x2, int y2) {
    int dx = x2 - x1;
    int dy = y2 - y1;
    int steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy);
    float xIncrement = dx / (float)steps;
    float yIncrement = dy / (float)steps;

    float x = x1;
    float y = y1;
    for (int i = 0; i <= steps; i++) {
        setPixel(round(x), round(y));
        x += xIncrement;
        y += yIncrement;
    }
}

void Bresenham(int x1, int y1, int x2, int y2) {
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);
    int p = 2 * dy - dx;
    int twody = 2 * dy;
    int twodydx = 2 * (dy - dx);
    int x, y, xEnd;

    if (x1 > x2) {
        x = x2;
        y = y2;
        xEnd = x1;
    }
    else {
        x = x1;
        y = y1;
        xEnd = x2;
    }

    setPixel(x, y);

    while (x < xEnd) {
        x++;
        if (p < 0) {
            p += twody;
        }
        else {
            y++;
            p += twodydx;
        }
        setPixel(x, y);
    }
}

void DottedLine(int x1, int y1, int x2, int y2) {
    glColor3f(1.0, 0.0, 0.0); // Color rojo para l�nea punteada
    glEnable(GL_LINE_STIPPLE);
    glLineStipple(1, 0x00FF); // Patr�n para l�nea punteada

    glBegin(GL_LINES);
    glVertex2i(x1, y1);
    glVertex2i(x2, y2);
    glEnd();

    glDisable(GL_LINE_STIPPLE);
}

void DashedLine(int x1, int y1, int x2, int y2) {
    glColor3f(0.0, 0.0, 1.0); // Color azul para l�nea discontinua
    glEnable(GL_LINE_STIPPLE);
    glLineStipple(1, 0x0F0F); // Patr�n para l�nea discontinua

    glBegin(GL_LINES);
    glVertex2i(x1, y1);
    glVertex2i(x2, y2);
    glEnd();

    glDisable(GL_LINE_STIPPLE);
}

void SolidLine(int x1, int y1, int x2, int y2) {
    glColor3f(0.0, 0.0, 0.0); // Color negro para l�nea s�lida

    glBegin(GL_LINES);
    glVertex2i(x1, y1);
    glVertex2i(x2, y2);
    glEnd();
}

void crearCasa(Casa& C) {
    // Fachada de la casa (rect�ngulo)
    glColor3f(1.0, 0.0, 0.0); // Rojo
    glBegin(GL_QUADS);
    glVertex2i(C.x, C.y);
    glVertex2i(C.x + C.ancho, C.y);
    glVertex2i(C.x + C.ancho, C.y + C.altura);
    glVertex2i(C.x, C.y + C.altura);
    glEnd();

    // Techo de la casa (tri�ngulo)
    glColor3f(0.0, 0.0, 1.0); // Azul
    glBegin(GL_TRIANGLES);
    glVertex2i(C.x, C.y + C.altura);
    glVertex2i(C.x + C.ancho / 2, C.y + C.altura * 1.5);
    glVertex2i(C.x + C.ancho, C.y + C.altura);
    glEnd();

    // Puerta de la casa (rect�ngulo)
    glColor3f(0.0, 1.0, 0.0); // Verde
    glBegin(GL_QUADS);
    glVertex2i(C.x + C.ancho / 4, C.y);
    glVertex2i(C.x + C.ancho / 2, C.y);
    glVertex2i(C.x + C.ancho / 2, C.y + C.altura / 2);
    glVertex2i(C.x + C.ancho / 4, C.y + C.altura / 2);
    glEnd();

    // Ventanas de la casa (cuadrados)
    glColor3f(1.0, 1.0, 0.0); // Amarillo
    glBegin(GL_QUADS);
    glVertex2i(C.x + C.ancho / 6, C.y + C.altura / 2);
    glVertex2i(C.x + C.ancho / 3, C.y + C.altura / 2);
    glVertex2i(C.x + C.ancho / 3, C.y + 2 * C.altura / 3);
    glVertex2i(C.x + C.ancho / 6, C.y + 2 * C.altura / 3);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2i(C.x + 2 * C.ancho / 3, C.y + C.altura / 2);
    glVertex2i(C.x + 5 * C.ancho / 6, C.y + C.altura / 2);
    glVertex2i(C.x + 5 * C.ancho / 6, C.y + 2 * C.altura / 3);
    glVertex2i(C.x + 2 * C.ancho / 3, C.y + 2 * C.altura / 3);
    glEnd();
}

void dibujarCasa() {
    Casa C;
    C.x = 100;
    C.y = 100;
    C.altura = 150;
    C.ancho = 200;
    crearCasa(C);
}

void crearCarro(Carro& V) {
    // Cuerpo del carro (rect�ngulo)
    glColor3f(0.0, 1.0, 1.0); // Cian
    glBegin(GL_QUADS);
    glVertex2i(V.x, V.y);
    glVertex2i(V.x + V.ancho, V.y);
    glVertex2i(V.x + V.ancho, V.y + V.altura / 2);
    glVertex2i(V.x, V.y + V.altura / 2);
    glEnd();

    // Parte superior del carro (rect�ngulo)
    glColor3f(0.0, 0.0, 1.0); // Azul
    glBegin(GL_QUADS);
    glVertex2i(V.x + V.ancho / 4, V.y + V.altura / 2);
    glVertex2i(V.x + 3 * V.ancho / 4, V.y + V.altura / 2);
    glVertex2i(V.x + 3 * V.ancho / 4, V.y + V.altura);
    glVertex2i(V.x + V.ancho / 4, V.y + V.altura);
    glEnd();

    // Ventanas del carro (cuadrados)
    glColor3f(1.0, 0.0, 1.0); // Magenta
    glBegin(GL_QUADS);
    glVertex2i(V.x + V.ancho / 3, V.y + V.altura / 2);
    glVertex2i(V.x + 2 * V.ancho / 3, V.y + V.altura / 2);
    glVertex2i(V.x + 2 * V.ancho / 3, V.y + 3 * V.altura / 4);
    glVertex2i(V.x + V.ancho / 3, V.y + 3 * V.altura / 4);
    glEnd();

    // Llantas del carro (c�rculos)
    glColor3f(0.0, 0.0, 0.0); // Negro
    glBegin(GL_POLYGON);
    for (int i = 0; i < 360; i++) {
        float theta = i * 3.14159 / 180;
        glVertex2f(V.x + V.ancho / 5 + cos(theta) * V.ancho / 10, V.y + V.altura / 4 + sin(theta) * V.altura / 4);
    }
    glEnd();

    glBegin(GL_POLYGON);
    for (int i = 0; i < 360; i++) {
        float theta = i * 3.14159 / 180;
        glVertex2f(V.x + 4 * V.ancho / 5 + cos(theta) * V.ancho / 10, V.y + V.altura / 4 + sin(theta) * V.altura / 4);
    }
    glEnd();
}

void dibujarCarro() {
    Carro V;
    V.x = 400;
    V.y = 100;
    V.altura = 50;
    V.ancho = 100;
    crearCarro(V);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Dibujar casa y carro
    dibujarCasa();
    dibujarCarro();

    // Dibujar l�neas con diferentes estilos
    glLineWidth(2.0); // Ancho de l�nea

    // L�nea s�lida
    SolidLine(50, 50, 200, 50);

    // L�nea punteada
    DottedLine(50, 100, 200, 100);

    // L�nea discontinua
    DashedLine(50, 150, 200, 150);

    // L�nea con algoritmo DDA
    DDA(50, 200, 200, 200);

    // L�nea con algoritmo Bresenham
    Bresenham(50, 250, 200, 250);

    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Casa y Carro");
    init();
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
*/